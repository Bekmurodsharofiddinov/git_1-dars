import React from "react";
import CardHeader from "../../components/CardHeader";
import CardServices from "../../components/CardServices";
export default () => (
	<div>
		<CardHeader />
		<CardServices />
	</div>
);
