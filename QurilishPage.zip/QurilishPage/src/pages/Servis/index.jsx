import React from "react";
import Ask from "../../components/Ask";
import Service from "../../components/Service";
export default () => {
	return (
		<div>
			<Service />
			<Ask />
		</div>
	);
};
