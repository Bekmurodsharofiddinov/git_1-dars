import React from "react";
import Sidebar from "../../components/Sidebar";
import Content from "../../components/Content";
import Navbar from "../../components/Navbar";
import Footer from "../../components/Footer";
import Ask from "../../components/Ask";
import Service from "../../components/Service";
import Blog from "../../pages/Blog";

export default () => <div style={{ height: "100vh" }}>home</div>;
