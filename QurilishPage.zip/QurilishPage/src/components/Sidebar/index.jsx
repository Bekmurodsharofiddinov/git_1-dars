import React from 'react';
import './index.css';

export default () => {
  return <div>Sidebar</div>;
};
