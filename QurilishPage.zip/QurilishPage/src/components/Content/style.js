/* Bu style yozish uchun */
