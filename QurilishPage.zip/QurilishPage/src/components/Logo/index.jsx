import React from 'react';

export default () => {
  return <div>Logo component</div>;
};
