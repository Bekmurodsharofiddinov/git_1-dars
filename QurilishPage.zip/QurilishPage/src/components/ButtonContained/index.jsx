import React from 'react';
import './index.css';

export default () => {
  return <div>Button</div>;
};
